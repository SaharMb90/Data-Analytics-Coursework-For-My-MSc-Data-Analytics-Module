import pandas as pd
import matplotlib.pyplot as plt


# Load the dataset
df = pd.read_csv("ScouseHumour.csv")

# Check the distribution of responses for this question Do you think there is something distinctive 
# about scouse humour?','Do you have any thoughts on what makes it distinctive?','Do you think humour can help people deal with difficult experiences?','If you answered yes or maybe, how do you think it helps?','Would you mind saying what age group you belong to?
response1_counts = df['Do you think there is something distinctive about scouse humour?'].value_counts()

# Plot the distribution of responses
plt.figure(figsize=(8, 6))
response1_counts.plot(kind='bar', color='green')
plt.title('Do you think there is something distinctive about scouse humour?')
plt.xlabel('Response')
plt.ylabel('Count')
plt.xticks(rotation=0)
plt.show()

positive_responses = df[df['Do you think there is something distinctive about scouse humour?'] == 'Yes']
negative_responses = df[df['Do you think there is something distinctive about scouse humour?'] == 'No']
neutral_responses = df[df['Do you think there is something distinctive about scouse humour?'] == 'Maybe']

# Print the number of positive, negative, and neutral responses
print("Number of Positive Responses (Yes):", len(positive_responses))
print("Number of Negative Responses (No):", len(negative_responses))
print("Number of Neutral Responses (Maybe):", len(neutral_responses))

# Check the distribution of responses for this question Do you think there is something distinctive about scouse humour?','Do you have any thoughts on what makes it distinctive?','Do you think humour can help people deal with difficult experiences?','If you answered yes or maybe, how do you think it helps?','Would you mind saying what age group you belong to?
response2_counts = df['Do you think humour can help people deal with difficult experiences?'].value_counts()
# Plot the distribution of responses
plt.figure(figsize=(8, 6))
response2_counts.plot(kind='bar', color='red')
plt.title('Do you think humour can help people deal with difficult experiences?')
plt.xlabel('Response')
plt.ylabel('Count')
plt.xticks(rotation=0)
plt.show()
positive_responses2 = df[df['Do you think humour can help people deal with difficult experiences?'] == 'Yes']
negative_responses2 = df[df['Do you think humour can help people deal with difficult experiences?'] == 'No']
neutral_responses2 = df[df['Do you think humour can help people deal with difficult experiences?'] == 'Maybe']

# Print the number of positive, negative, and neutral responses
print("Number of Positive Responses (Yes):", len(positive_responses2))
print("Number of Negative Responses (No):", len(negative_responses2))
print("Number of Neutral Responses (Maybe):", len(neutral_responses2))

# Check the distribution of responses for the age group question
age_group_counts = df['Would you mind saying what age group you belong to?'].value_counts()

# Plot the distribution of responses using a pie chart
plt.figure(figsize=(8, 8))
plt.pie(age_group_counts, labels=age_group_counts.index, autopct='%1.1f%%', colors=['purple', 'lightgreen', 'orange', 'blue', 'red', 'cyan', 'yellow', 'gray', 'brown', 'pink'])
plt.title('Distribution of Age Groups')
plt.show()


# Filter the DataFrame for 'Yes', 'No', and 'Maybe' responses
filtered_df = df[df['Do you think humour can help people deal with difficult experiences?'].isin(['Yes', 'No', 'Maybe'])]

# Group by age range and count the responses
age_group_counts2 = filtered_df.groupby('Would you mind saying what age group you belong to?')['Do you think humour can help people deal with difficult experiences?'].value_counts().unstack()

# Plot the grouped bar chart
age_group_counts2.plot(kind='bar', figsize=(10, 6))
plt.title('Responses by Age Group')
plt.xlabel('Age Group')
plt.xticks(rotation=45)
plt.legend(title='Do you think humour can help people deal with difficult experiences?')
plt.ylabel('Number of Samples')
plt.xticks(rotation=45)
plt.ylim(0, 105)  # Set y-axis limits
plt.show()

# Count the number of responses for each region
responses_counts2 = df['How would you identify yourself from the following:'].value_counts()

# Plot the distribution of responses using a pie chart
plt.figure(figsize=(8, 8))
plt.pie(responses_counts2, labels=responses_counts2.index, autopct='%1.1f%%', colors=['skyblue', 'lightgreen', 'orange', 'yellow', 'purple', 'pink'])
plt.title('Distribution of regions')
plt.show()