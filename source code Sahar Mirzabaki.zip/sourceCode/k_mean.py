import pandas as pd
from preprocessing import preprocess_text
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt


# Load the dataset
df = pd.read_csv("preprocessed_dataset.csv")

# Fill NaN values with empty strings
df['Do you have any thoughts on what makes it distinctive?'].fillna('', inplace=True)

# Apply text preprocessing to the column
df['cleaned_responses'] = df['Do you have any thoughts on what makes it distinctive?'].apply(preprocess_text)

# Create TF-IDF matrix
tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2, stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(df['cleaned_responses'])

# Determine the optimal number of clusters using silhouette score
max_clusters = 10
silhouette_scores = []
for k in range(2, max_clusters+1):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(tfidf_matrix)
    silhouette_scores.append(silhouette_score(tfidf_matrix, kmeans.labels_))

# Plot silhouette scores to find the optimal number of clusters
plt.plot(range(2, max_clusters+1), silhouette_scores, marker='o')
plt.xlabel('Number of Clusters')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score vs Number of Clusters')
plt.show()

# Based on the silhouette score, choose the optimal number of clusters
optimal_num_clusters = silhouette_scores.index(max(silhouette_scores)) + 2  # Add 2 because the range started from 2

# Perform K-means clustering
kmeans = KMeans(n_clusters=optimal_num_clusters, random_state=42)
kmeans.fit(tfidf_matrix)

# Add cluster labels to the dataframe
df['cluster_label'] = kmeans.labels_

# Print the clusters and their corresponding responses
for cluster_id in range(optimal_num_clusters):
    print(f"Cluster {cluster_id}:")
    cluster_responses = df[df['cluster_label'] == cluster_id]['cleaned_responses'].tolist()
    for response in cluster_responses:
        print(response)
    print("\n")
