import pandas as pd
from preprocessing import preprocess_text
from wordcloud import WordCloud
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("ScouseHumour.csv")

# Apply preprocessing function to all columns in your dataset
df = df.applymap(preprocess_text)
# Drop duplicates
df.drop_duplicates(inplace=True)

# Drop rows with missing values
df.dropna(inplace=True)

# Save the preprocessed dataset
df.to_csv("preprocessed_dataset.csv", index=False)

# Apply text preprocessing to the column
df['cleaned_thoughts'] = df['Do you have any thoughts on what makes it distinctive?'].apply(preprocess_text)

# Create a WordCloud to visualize the most common words
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(' '.join(df['cleaned_thoughts']))

# Plot the WordCloud
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud of Thoughts on "Do you have any thoughts on what makes it distinctive?"')
plt.show()

# Perform Topic Modeling using Latent Dirichlet Allocation (LDA)
tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2, stop_words='english')
tfidf = tfidf_vectorizer.fit_transform(df['cleaned_thoughts'])
lda = LatentDirichletAllocation(n_components=5, random_state=42)
lda.fit(tfidf)
feature_names = tfidf_vectorizer.get_feature_names_out()
n_top_words = 10
topic_words = {}
for topic_idx, topic in enumerate(lda.components_):
    topic_words[topic_idx] = [feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]]

# Print top words for each topic
for topic, words in topic_words.items():
    print(f"Topic {topic}: {' '.join(words)}")