import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import re


# Ensure NLTK resources are downloaded
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Define a function for text preprocessing
def preprocess_text(text):
    # Check if text is a string
    if isinstance(text, str):
        # Lowercasing
        text = text.lower()
        # Replace repeated characters (e.g., quickkkkkkk -> quick)
        text = re.sub(r'(.)\1{2,}', r'\1', text)
        # Tokenization
        tokens = word_tokenize(text)
        # Lemmatization
        lemmatizer = WordNetLemmatizer()
        tokens = [lemmatizer.lemmatize(token) for token in tokens]
        processed_text = ' '.join(tokens)
        return processed_text
    else:
        # If not a string, return original value
        return text


